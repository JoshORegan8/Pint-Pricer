package com.example.practice;



import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.SetOptions;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";

    private static final String KEY_REVIEW = "review";


    private EditText editTextReview;

    private TextView textViewData;

    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private CollectionReference reviewRef = db.collection("Review");
    private DocumentReference reviewDoc = db.document("Review/Bar Review");


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextReview = findViewById(R.id.TextRev);

        textViewData = findViewById(R.id.textViewRev);
    }


    public void giveReview(View view){
        Intent intent = new Intent (this, ReviewPage.class);
        startActivity(intent);
    }
    public void deleteRev(View view){
        EditText revView = (EditText) findViewById(R.id.TextRev);
        reviewDoc.update(KEY_REVIEW, FieldValue.delete());
        revView.setText("");
    }

    public void updateReview(View v){
        String review = editTextReview.getText().toString();

       // Map<String, Object> rev = new HashMap<>();
        //rev.put(KEY_REVIEW, review);

       // reviewDoc.set(rev, SetOptions.merge());

        reviewDoc.update(KEY_REVIEW, review);


    }

    public void saveRev(View v) {
        String review = editTextReview.getText().toString();


        Map<String, Object> rev = new HashMap<>();
        rev.put(KEY_REVIEW, review);

        reviewDoc.set(rev)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Toast.makeText(MainActivity.this , "Review Saved", Toast.LENGTH_SHORT).show();

                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(MainActivity.this , "Review Saved", Toast.LENGTH_SHORT).show();
                        Log.d(TAG, e.toString());
                    }
                });


        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }



    public void fetchReview(View v) {
        reviewDoc.get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {
                            String review = documentSnapshot.getString(KEY_REVIEW);


                            //Map<String, Object> note = documentSnapshot.getData();

                            textViewData.setText("\n" + review + "\n\n");
                        } else {
                            Toast.makeText(MainActivity.this, "No Review", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(MainActivity.this, "No Review", Toast.LENGTH_SHORT).show();
                        Log.d(TAG, e.toString());
                    }
                });
    }
}