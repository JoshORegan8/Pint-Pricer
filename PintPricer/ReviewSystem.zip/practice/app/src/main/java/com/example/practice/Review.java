package com.example.practice;

import com.google.firebase.firestore.Exclude;

public class Review {
    private String rev;
    private String documentId;

    public Review(){}

    @Exclude
    public String getDocumentId() {
        return documentId;
    }

    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }
    public Review(String rev){
        this.rev = rev;
    }


    public String getRev() {
        return rev;
    }
}
